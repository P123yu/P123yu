package com.cms.pojo; // package // plane old java project 

public class Farm { // public class 

    //3. private data

    private int farmNumber;
    private String farmName;
    private String farmLocation;

    public Farm() {
        System.out.println("Farm constructor");
    }

    public int getFarmNumber() {
        return farmNumber;
    }

    public String getFarmName() {
        return farmName;
    }

    public void setFarmNumber(int farmNumber) {
        this.farmNumber = farmNumber;
    }

    public void setFarmName(String farmName) {
        this.farmName = farmName;
    }

    public String getFarmLocation() {
        return farmLocation;
    }

    public void setFarmLocation(String farmLocation) {
        this.farmLocation = farmLocation;
    }

}
