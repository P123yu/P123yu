package com.cms.dao;

import java.util.List;

import com.cms.pojo.*
;

// CRUD methods are here 
public interface FarmDAO {

    void             insertFarm(Farm farmer);          
    Farm             selectFarm(int farmNumber);      
    List<Farm>       selectFarms();                   
    void             updateFarm(Farm farmer);         
    void             deleteFarm(int farmNumber);
	      
}
