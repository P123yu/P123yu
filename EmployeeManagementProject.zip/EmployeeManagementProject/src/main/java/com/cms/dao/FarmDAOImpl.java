package com.cms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cms.myexceptions.FarmNotFoundException;
import com.cms.pojo.Farm;

public class FarmDAOImpl implements FarmDAO {

    Connection conn;

    public FarmDAOImpl() {
        try {
            System.out.println("Trying to load the database driver...");
            DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
            System.out.println("Database driver loaded...");

            // 2. GET THE CONNECTION
            System.out.println("Trying to connect to the database...");
            this.conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "system");

            System.out.println("Connected to the DB : " + conn);

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    @Override
    public void insertFarm(Farm farmer) {

        try {
            PreparedStatement pst = conn.prepareStatement("INSERT INTO FARMER "
                    + "VALUES (?,?,?)");

            pst.setInt(1, farmer.getFarmNumber());
            pst.setString(2, farmer.getFarmName());
            pst.setString(3, farmer.getFarmLocation());

            int rows = pst.executeUpdate();
            System.out.println("Rows added : " + rows);
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    
    @Override
    public Farm selectFarm(int farmNumber) {
        Farm farmer = null;
        try {
            Statement statement = conn.createStatement();
            ResultSet result = statement.executeQuery("SELECT * FROM farmer where farmerid=" + farmNumber);
            if (result.next()) {
                farmer = new Farm();
                farmer.setFarmNumber(result.getInt(1));
                farmer.setFarmName(result.getString(2));
                farmer.setFarmLocation(result.getString(3));
                
            } else {
                throw new FarmNotFoundException("The farm with this id does not exist !!! " + farmNumber);
            }
            statement.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return farmer;
    }



    @Override
    public List<Farm> selectFarms() {
        Farm farmer = null;
        List<Farm> list = new ArrayList<Farm>();

        try {
            Statement statement = conn.createStatement();
            ResultSet result = statement.executeQuery("SELECT * FROM farmer");

            while (result.next()) {
                farmer = new Farm(); // blank object
                farmer.setFarmNumber(result.getInt(1)); // fill up the object
                farmer.setFarmName(result.getString(2));
                farmer.setFarmLocation(result.getString(3));
                list.add(farmer); // add this object to the array list..
            }

            statement.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return list;
    }

    
    
    @Override
    public void updateFarm(Farm farmer) {
        try {
            PreparedStatement pst = conn.prepareStatement("UPDATE farmer SET FARMERNAME = ?, FARMERLOCATION = ? WHERE FARMERid = ?");

            pst.setString(1, farmer.getFarmName());
            pst.setString(2, farmer.getFarmLocation());
            pst.setInt(3, farmer.getFarmNumber());

            int rows = pst.executeUpdate();
            System.out.println("Rows updated : " + rows);
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }
    

    @Override
    public void deleteFarm(int farmNumber) {

        try {
            PreparedStatement pst = conn.prepareStatement("delete from farmer  "
                    + " where farmerid=?");

            pst.setInt(1, farmNumber);

            int rows = pst.executeUpdate();
            System.out.println("Rows deleted : " + rows);
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }
    

}
