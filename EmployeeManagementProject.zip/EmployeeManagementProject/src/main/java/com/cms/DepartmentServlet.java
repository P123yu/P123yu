package com.cms;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cms.dao.DepartmentDAO;
import com.cms.dao.DepartmentDAOImpl;
import com.cms.myexceptions.*;
import com.cms.pojo.Department;
import com.cms.pojo.Farm;
import com.cms.dao.FarmDAO;
import com.cms.dao.FarmDAOImpl;

@WebServlet("/depts")
public class DepartmentServlet extends HttpServlet {

	//hasA
	DepartmentDAO deptDAO = new DepartmentDAOImpl();

	
    public DepartmentServlet() {
        super();
        System.out.println("DepartmentServlet() constructor");

    }


	public void init(ServletConfig config) throws ServletException {

		System.out.println("init() invoked....");
	}


	public void destroy() {
		System.out.println("destroy() invoked....");

	}



	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		//System.out.println("doGet() invoked...."+request.getRemoteAddr());
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		pw.println("<h2> Welcome from : "+request.getRemoteAddr()+"</h3>");
		pw.println("<a href='http://10.16.8.255:8080/EmployeeManagementProject/'>Back</a>\r\n");
	
		pw.println("<table border=5>");
		
			pw.println("<tr>");
				pw.println("<th>");
					pw.println("DEPTNO");
				pw.println("</th>");
				
				
				pw.println("<th>");
					pw.println("DNAME");
				pw.println("</th>");
			
			
			pw.println("<th>");
				pw.println("LOC");
			pw.println("</th>");
		
			pw.println("</tr>");

			
	
			List<Department> deptList = deptDAO.selectDepartments();
			
			
			
			for(Department dept  : deptList ) { //JAVA CODING
					pw.println("<tr>"); //HTML
		
						pw.println("<td>"); //HTML
							pw.println(dept.getDepartmentNumber()); //JAVA CODE
						pw.println("</td>"); //HTML 	
					
					
						pw.println("<td>");
							pw.println(dept.getDepartmentName());
						pw.println("</td>");
				
				
						pw.println("<td>");
							pw.println(dept.getDepartmentLocation());
						pw.println("</td>");
				
						pw.println("<td>");
							pw.println("<BUTTON style='background-color:blue'>Modify</BUTTON>  <BUTTON style='background-color:red'>Delete</BUTTON>");
						pw.println("</td>");
			
						
					pw.println("</tr>");
			}
			
		pw.println("</table>");

		
		
		


        com.cms.dao.FarmDAO farmDAO = new FarmDAOImpl();

		List<Farm> farmList = farmDAO.selectFarms();
		
		pw.println("<HR>");

		
		
		pw.println("<table border=5>");
		
		
		pw.println("<tr>");
			pw.println("<th>");
				pw.println("FARMER ID");
			pw.println("</th>");
			
			
			pw.println("<th>");
				pw.println("FARMER NAME");
			pw.println("</th>");
		
		
		pw.println("<th>");
			pw.println("FARMER LOCATION");
		pw.println("</th>");
	
		pw.println("</tr>");

		
		
		for(Farm farm  : farmList ) { //JAVA CODING
				pw.println("<tr>"); //HTML
	
					pw.println("<td>"); //HTML
						pw.println(farm.getFarmNumber()); //JAVA CODE
					pw.println("</td>"); //HTML 	
				
				
					pw.println("<td>");
						pw.println(farm.getFarmName());
					pw.println("</td>");
			
			
					pw.println("<td>");
						pw.println(farm.getFarmLocation());
					pw.println("</td>");
			
				pw.println("</tr>");
		}
		
	pw.println("</table>");

	}
	

}
