package com.cms.myexceptions;

public class FarmNotFoundException extends RuntimeException {
    public FarmNotFoundException(String msg) {
        super(msg);
    }
}
