package com.cms.myexceptions;
public class DepartmentNotFoundException extends RuntimeException {
	public DepartmentNotFoundException(String msg) {
		super(msg);
	}
}

